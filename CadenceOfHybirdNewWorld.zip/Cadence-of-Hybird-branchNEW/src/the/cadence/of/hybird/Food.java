/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package the.cadence.of.hybird;

/**
 *
 * @author Gabriel Nillos
 */
public class Food {
  private int lengthIncrease;
  private String foodName;
  private int foodXIndex,  foodYIndex;
  private String imageSrc;

  public Food (int l, String n, int foodXIndex, int foodYIndex,  String i){
    lengthIncrease = l;
    foodName = n;
    this.foodXIndex = foodXIndex;
    this.foodYIndex = foodYIndex;
    imageSrc = i;
  }

    public int getLengthIncrease() {
        return lengthIncrease;
    }
   
    public String getFoodName() {
        return foodName;
    }
  
  
}