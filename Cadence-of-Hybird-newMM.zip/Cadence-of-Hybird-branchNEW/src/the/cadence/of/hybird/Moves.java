/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package the.cadence.of.hybird;

/**
 *
 * @author Gabriel Nillos
 */
public interface Moves {
    void moveLeft(Level level);
    void moveRight();
    void moveUp();
    void moveDown();
}